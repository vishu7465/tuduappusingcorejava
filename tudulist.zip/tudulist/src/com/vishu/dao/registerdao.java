package com.vishu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.vishu.model.product;
import com.vishu.model.register;

public class registerdao {
	private static registerdao userDao = new registerdao();

	public registerdao() {
	}

	public static registerdao getUserDao() {
		return userDao;
	}
	public int insert(register user) {
		int i = 0;
		try (Connection con = Dao.getConnection();) {
			PreparedStatement ps = con.prepareStatement("insert into register values(?,?,?,?)");
			ps.setString(1, user.getName());
			ps.setString(2, user.getEmail());
			ps.setString(3, user.getPhone());
			ps.setString(4, user.getPass());
			
			i = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return i;
	}

public register login(String email ,String pass)  {
	register rd=null;
	try (Connection con = Dao.getConnection();) {
	PreparedStatement ps = con.prepareStatement("select * from register where email=? and password=?");
	ps.setString(1, email);
	ps.setString(2, pass);
	
 ResultSet rs=ps.executeQuery();
	if(rs.next())
{
		rd=new register();
		rd.setName(rs.getString(1));
		rd.setEmail(rs.getString(2));
		rd.setPhone(rs.getString(3));
		
		rd.setPass(rs.getString(4));
}
}catch(Exception e ) {
System.out.println(e);
	
}
	return rd;
}
public int pro(product pro) {
	int j = 0;
	try (Connection con = Dao.getConnection();) {
		PreparedStatement ps = con.prepareStatement("insert into product values(?,?,?,?,?)");
		ps.setString(1, pro.getProductname());
		ps.setString(2, pro.getProductp());
		ps.setString(3, pro.getDetails());
		ps.setString(4, pro.getDprice());
		ps.setString(5, pro.getUid());
		j = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	return j;
}
	
}

