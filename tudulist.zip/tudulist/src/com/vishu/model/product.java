package com.vishu.model;

public class product {

	private String productname;
	private String productp;
	private String details;
	private String dprice;
	private String uid;
	
	public product(String productname, String productp,String details, String dprice,String uid) 
	{
		this.productname = productname;
		this.productp = productp;
	     this.details=details;
		this.dprice = dprice;
		this.uid=uid;
	}
	public product() {
		
	}
	
	
	
	
	
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProductp() {
		return productp;
	}
	public void setProductprice(String productp) {
		this.productp = productp;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getDprice() {
		return dprice;
	}
	public void setDprice(String dprice) {
		this.dprice = dprice;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	
}
