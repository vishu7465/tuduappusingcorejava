package com.vishu.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.vishu.dao.registerdao;
import com.vishu.model.register;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class login extends JFrame {

	private JPanel contentPane;
	private JTextField temail;
	private JPasswordField tpass;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 645, 546);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.setLocation(350, 200);
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(253, 21, 83, 32);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(120, 135, 86, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(120, 206, 86, 14);
		panel.add(lblNewLabel_2);
		
		temail = new JTextField();
		temail.setBounds(311, 117, 123, 32);
		panel.add(temail);
		temail.setColumns(10);
		
		tpass = new JPasswordField();
		tpass.setBounds(311, 188, 123, 32);
		panel.add(tpass);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(valid()) {
				
					
					 register	r = registerdao.getUserDao().login(email, pass);
		              tudolist h=new tudolist();
		              h.setVisible(true);
		              dispose();
					if(r !=null) {
				JOptionPane.showMessageDialog(login.this, "successfully login");
					}else {
						JOptionPane.showMessageDialog(login.this, "Invalid email and password");
					
					}
				}
				
			}
		});
		btnNewButton.setBounds(221, 270, 89, 23);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(login.class.getResource("/image/tudu.jpg")));
		lblNewLabel_3.setBounds(0, 0, 619, 497);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New User ? Register !!");
		lblNewLabel_4.setCursor(new Cursor(HAND_CURSOR));
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				registerpage r=new registerpage();
				r.setVisible(true);
				dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_4.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_4.setForeground(Color.black);
			}
		});
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_4.setBounds(221, 318, 175, 14);
		lblNewLabel_3.add(lblNewLabel_4);
	}
	public String name,email,phone,pass;
	public boolean valid() {
		
		email=temail.getText();
	
		pass = String.valueOf(tpass.getPassword());
	
		 if (email.isEmpty()) {
			JOptionPane.showMessageDialog(this, "please enter email");
			temail.requestFocus();
			return false;
	
	}else if (pass.isEmpty()) {
		JOptionPane.showMessageDialog(this, "please enter phone password");
		tpass.requestFocus();
		return false;
}
	else {
		return true;
				
	}
	}
}
