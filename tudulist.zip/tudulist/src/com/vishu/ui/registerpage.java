package com.vishu.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.vishu.dao.Dao;
import com.vishu.dao.registerdao;
import com.vishu.model.register;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class registerpage extends JFrame {

	private JPanel contentPane;
	private JTextField tname;
	private JTextField temail;
	private JTextField tphone;
	private JPasswordField tpass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registerpage frame = new registerpage();
					frame.setVisible(true);
					frame.setLocation(350, 200);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registerpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 754, 572);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Register");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblNewLabel.setBounds(296, 0, 102, 45);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setForeground(new Color(51, 0, 102));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(166, 125, 76, 39);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email Id");
		lblNewLabel_2.setForeground(new Color(51, 0, 102));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(166, 175, 76, 23);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Phone No.");
		lblNewLabel_3.setForeground(new Color(51, 0, 102));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(166, 231, 76, 23);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setForeground(new Color(51, 0, 102));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setBounds(166, 285, 76, 23);
		panel.add(lblNewLabel_4);
		
		tname = new JTextField();
		tname.setBounds(340, 120, 124, 26);
		panel.add(tname);
		tname.setColumns(10);
		
		temail = new JTextField();
		temail.setBounds(340, 172, 124, 26);
		panel.add(temail);
		temail.setColumns(10);
		
		tphone = new JTextField();
		tphone.setBounds(340, 228, 124, 26);
		panel.add(tphone);
		tphone.setColumns(10);
		
		tpass = new JPasswordField();
		tpass.setBounds(340, 276, 124, 26);
		panel.add(tpass);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
if (valid()) {
					
					int callback = registerdao.getUserDao().insert(new register(name, email,phone,pass));
					if (callback > 0) {
						JOptionPane.showMessageDialog(registerpage.this, "registeration success");
				login n=new login();
				n.setVisible(true);
				dispose();
						} else {
						JOptionPane.showMessageDialog(registerpage.this, "registeration failed");
					}

				}
			
			
			
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(272, 344, 102, 33);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(registerpage.class.getResource("/image/tudu.jpg")));
		lblNewLabel_5.setBounds(0, 0, 728, 535);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Already Register ? Login !!");
		lblNewLabel_6.setCursor(new Cursor(HAND_CURSOR));
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			new login().setVisible(true);
			dispose();
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_6.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_6.setForeground(Color.black);
			}
		});
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_6.setBounds(248, 398, 190, 14);
		lblNewLabel_5.add(lblNewLabel_6);
	}
	public String name,email,phone,pass;
	public boolean valid() {
		name=tname.getText();
		email=temail.getText();
		phone=tphone.getText();
		pass = String.valueOf(tpass.getPassword());
		if (name.isEmpty()) {
			JOptionPane.showMessageDialog(this, "please enter name");
			tname.requestFocus();
			return false;
		} else if (email.isEmpty()) {
			JOptionPane.showMessageDialog(this, "please enter email");
			temail.requestFocus();
			return false;
	}else if (phone.isEmpty()) {
		JOptionPane.showMessageDialog(this, "please enter phone number");
		tphone.requestFocus();
		return false;
	}else if (pass.isEmpty()) {
		JOptionPane.showMessageDialog(this, "please enter phone password");
		tpass.requestFocus();
		return false;
}
	else {
		return true;
				
	}
	}
}
