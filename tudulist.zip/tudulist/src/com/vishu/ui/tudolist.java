package com.vishu.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.vishu.dao.registerdao;
import com.vishu.model.product;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class tudolist extends JFrame {

	private JPanel contentPane;
	private static JTextField tname;
	private static JTextField tprice;
	private static JTextField tdetails;
	private static JTextField tdprice;
	private static JTextField tid2;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tudolist frame = new tudolist();
					frame.setVisible(true);
					frame.setLocation(350, 200);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tudolist() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 731, 573);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		 JTable table = new JTable(); 
		 table = new JTable();
			
	        // create a table model and set a Column Identifiers to this model 
	        Object[] columns = {"Name","Price","Details","Discount"};
	        DefaultTableModel model = new DefaultTableModel();
	        model.setColumnIdentifiers(columns);
	        
	        // set the model to the table
	        table.setModel(model);
	        table.setBackground(Color.LIGHT_GRAY);
	        table.setForeground(Color.black);
	        Font font = new Font("",1,22);
	        table.setFont(font);
	        table.setRowHeight(30);
		panel.setLayout(null);
		JLabel lblNewLabel_5 = new JLabel("Tudo List");
		lblNewLabel_5.setBounds(226, 11, 208, 38);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 22));
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel = new JLabel("Product");
		lblNewLabel.setBounds(33, 133, 46, 14);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Price");
		lblNewLabel_1.setBounds(151, 133, 46, 14);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Details");
		lblNewLabel_2.setBounds(262, 133, 46, 14);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Discount");
		lblNewLabel_3.setBounds(371, 133, 55, 14);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Id");
		lblNewLabel_4.setBounds(501, 133, 46, 14);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(lblNewLabel_4);
		
		tname = new JTextField();
		tname.setBounds(21, 182, 100, 25);
		panel.add(tname);
		
		tprice = new JTextField();
		tprice.setBounds(135, 184, 100, 25);
		panel.add(tprice);
		
		tdetails = new JTextField();
		tdetails.setBounds(262, 184, 100, 25);
		panel.add(tdetails);
		
		tdprice = new JTextField();
		tdprice.setBounds(376, 184, 100, 25);
		panel.add(tdprice);
		
		tid2 = new JTextField();
		tid2.setBounds(493, 184, 100, 25);
		panel.add(tid2);
		Object[] row = new Object[4];
		JButton btnAdd = new JButton("Add");
		btnAdd.setBounds(111, 252, 145, 25);
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  row[0] = tname.getText();
	                row[1] = tprice.getText();
	                row[2] = tdetails.getText();
	                row[3] = tdprice.getText();
	                
	                // add row to the model
	                model.addRow(row);
			}
		});
		 table.addMouseListener(new MouseAdapter(){
		        
		        @Override
		        public void mouseClicked(MouseEvent e){
		            
		            /* i = the index of the selected row
		          int i=table.getSelectedColumn();
		            tname.setText(model.getValueAt(i, 0).toString());
		            tprice.setText(model.getValueAt(i, 1).toString());
		            tdetails.setText(model.getValueAt(i, 2).toString());
		            tdprice.setText(model.getValueAt(i, 3).toString());
		        */}
		        });
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(btnAdd);
		
		JButton btnNewButton = new JButton("Update Record");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				if(valid()) {
					int callback = registerdao.getUserDao().pro(new product(productname,productp,details,dprice,uid));
					if (callback > 0) {
						JOptionPane.showMessageDialog(tudolist.this, "added successfully to databse");
						
				
						} else {
						JOptionPane.showMessageDialog(tudolist.this, "Failed to add product");
					}
					 
					}
				
        	
			}
		});
		btnNewButton.setBounds(346, 252, 130, 24);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		panel.add(btnNewButton);
		
		JScrollPane pane = new JScrollPane((Component) null);
		pane.setBounds(33, 288, 614, 224);
		panel.add(pane);
		pane.setViewportView(table);
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon(tudolist.class.getResource("/image/tudu.jpg")));
		lblNewLabel_6.setBounds(0, 0, 705, 524);
		panel.add(lblNewLabel_6);
		
	}

	public static String productname;
	public static String productp;
	public static String details;
	public static String dprice;
	public static String uid;
	
	public static boolean valid() {
		productname=tname.getText();
		productp=tprice.getText();
		details=tdetails.getText();
		dprice=tdprice.getText();
		uid=tid2.getText();
		if (productname.isEmpty()) {
			JOptionPane.showMessageDialog(tname, "Enter Name");
			tname.requestFocus();
			return false;
		} else if (productp.isEmpty()) {
			JOptionPane.showMessageDialog(tprice, "please enter product price");
			tprice.requestFocus();
			return false;
	}else if (details.isEmpty()) {
		JOptionPane.showMessageDialog(tdetails, "please enter product details");
		tdetails.requestFocus();
		return false;
	}else if (dprice.isEmpty()) {
		JOptionPane.showMessageDialog(tdprice, "please enter discount price");
		tdprice.requestFocus();
		return false;
}else if (uid.isEmpty()) {
	JOptionPane.showMessageDialog(tid2, "please enter unique id");
	tid2.requestFocus();
	return false;
}
	else {
		return true;
				
	}
	}

	

}
